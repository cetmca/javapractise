package com.online.dmi.test;

public class Consumer extends MoneyMarket {

	public Consumer() {
		super();
		// TODO Auto-generated constructor stub
		this.typeOfAccount="Consumer";
		this.withDrawelLimit=750;
	}

}
