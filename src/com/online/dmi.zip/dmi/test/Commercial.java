package com.online.dmi.test;

public class Commercial extends MoneyMarket{

	public Commercial() {
		super();
		// TODO Auto-generated constructor stub
		this.typeOfAccount="Commercial";
	}

}
