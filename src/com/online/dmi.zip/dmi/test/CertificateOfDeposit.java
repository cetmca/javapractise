package com.online.dmi.test;

public class CertificateOfDeposit extends Accounts {

}
