package com.online.dmi.test;

public class MoneyMarket extends Accounts {

}
