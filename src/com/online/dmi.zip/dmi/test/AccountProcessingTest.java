package com.online.dmi.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class AccountProcessingTest {
	
	AccountProcessing acctproc = new AccountProcessing();
	Accounts acc = new  Consumer();
	Accounts toacc = new  Consumer();
		

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testDeposit() {
		String status = acctproc.deposit(acc, 1000);
		assertEquals(status,"SUCCESS");
		//fail("Not yet implemented");
	}
	
	
	@Test
	public void testWithdrawal() {
		String status = acctproc.withdrawal(acc, 1000);
		assertEquals(status,"SUCCESS");
		//fail("Not yet implemented");
	}
	
	@Test
	public void testTranfer() throws Exception {
		String status = acctproc.transfer(acc, toacc, 500);
		assertEquals(status,"SUCCESS");
		//fail("Not yet implemented");
	}

}
